# -*- coding: utf-8 -*-
"""
Created on Sat Aug 15 09:02:00 2020

@author: V1kt0r
"""

def get_image(url):
    opener=urllib.request.build_opener()
    opener.addheaders=[('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1941.0 Safari/537.36')]
    urllib.request.install_opener(opener)
    socket.setdefaulttimeout(180)
    file_name=url.replace('/', '').replace(':', '')
    image_name=os.getcwd()+"/"+file_name
    if os.path.isfile(os.getcwd()+"/"+file_name)==False:
        try:
            urllib.request.urlretrieve(url,filename=image_name)
        except socket.timeout:
            count = 1
            while count <= 5:
                try:
                    urllib.request.urlretrieve(url,filename=image_name)                                                
                    break
                except socket.timeout:
                    err_info = 'Reloading for %d time'%count if count == 1 else 'Reloading for %d times'%count
                    print(err_info)
                    count += 1
            if count > 5:
                print("downloading picture fialed!")
    
    return
import requests  
import random
import socket
import re
import urllib
import os.path
import configparser
#from PyQt5.QtWebEngineWidgets import QWebEngineView
def trans(a,b,c,d="",e=""):
    #用于替换文本两端指定文本
    mid=a.replace(b,d)
    mid=mid.replace(c,e)
    return mid
#browser = QWebEngineView()
#browser.load(QUrl("https://blog.csdn.net/s_daqing"))
#browser.show()
config = configparser.RawConfigParser()
file_address='config.ini'
config.read(file_address)
value = config.get('config', 'tags')
surl=config.get('config', 'url')
tags=re.findall(r"\[.*?\]", value)
tag=random.choice(tags)
tag_handle=trans(tag,'[', ']')
urlp=surl+tag_handle
#print(urlp)

response=requests.get(urlp)
url=re.findall(r"addUrl\(\'http.*?\'",response.text,flags=0)
item=re.findall(r"ajaxs\(\'.*?\',\'http",response.text,flags=0)
item=re.findall(r"ajaxs\(\'.*?\',\'http",response.text,flags=0)
urlc=random.choice(url)
urla=trans(urlc, "addUrl(\'", "\'").strip()
get_image(urla)
